Install the requirements

pip install -r requirements.txt